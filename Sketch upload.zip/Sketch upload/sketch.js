let shapeType = 0; // 0 for ellipse, 1 for rectangle, 2 for triangle
let currentColor;
let prevX, prevY;
let targetSize = 30;
let shapeSize = 30;
let pastelColors;
let isMousePressed = false;

function setup() {
  let canvas = createCanvas(1790, 1030);
  canvas.position(0, 0); // Position the canvas at (0, 0)

  noStroke(); // No outline for shapes
  pastelColors = [
    color(255, 191, 186, 100), // Light Pink
    color(255, 214, 153, 100), // Light Orange
    color(211, 232, 239, 100), // Light Blue
    color(206, 168, 220, 100), // Light Purple
    color(173, 216, 230, 100), // Light Cyan
  ];

  currentColor = random(pastelColors);
  prevX = mouseX;
  prevY = mouseY;

  // Create a reset button and position it at the top-right corner
  let resetButton = createButton('Reset');
  resetButton.position(width - resetButton.width - 10, 10);
  resetButton.mousePressed(resetCanvas);
}

function draw() {
  if (isMousePressed) {
    // Use shapeType to determine the shape to draw
    if (shapeType === 0) {
      fill(currentColor);
      ellipse(mouseX, mouseY, shapeSize, shapeSize);
    } else if (shapeType === 1) {
      fill(currentColor);
      rect(mouseX - shapeSize / 2, mouseY - shapeSize / 2, shapeSize, shapeSize);
    } else if (shapeType === 2) {
      fill(currentColor);
      triangle(
        mouseX - shapeSize / 2, mouseY + shapeSize / 2,
        mouseX + shapeSize / 2, mouseY + shapeSize / 2,
        mouseX, mouseY - shapeSize / 2
      );
    }

    // Smooth the mouse movement with a watercolor effect
    for (let i = 0; i < 1; i += 0.1) {
      let smoothX = lerp(prevX, mouseX, i);
      let smoothY = lerp(prevY, mouseY, i);
      fill(255, 20); // Use white (255) for smoothing with a lower opacity (watercolor effect)
      ellipse(smoothX, smoothY, 2, 2);
    }

    // Update the previous mouse position
    prevX = mouseX;
    prevY = mouseY;

    // Transition the shape size toward the target size
    shapeSize = lerp(shapeSize, targetSize, 0.1);

    // If the shape size is close to the target size, change the target size and shape type
    if (abs(shapeSize - targetSize) < 1) {
      targetSize = random(10, 100); // Random target size
      shapeType = int(random(3)); // Random shape type (0, 1, or 2)
      currentColor = random(pastelColors); // Random pastel color
    }
  }
}

function resetCanvas() {
  background(255); // Set the background to white (255)
}

function mousePressed() {
  isMousePressed = true;
  // Change the shape type and size when the mouse is pressed
  shapeType = int(random(3)); // Random shape type (0, 1, or 2)
  shapeSize = random(10, 100); // Random shape size
  targetSize = shapeSize; // Initialize target size to current size
  currentColor = random(pastelColors); // Random pastel color
}

function mouseReleased() {
  isMousePressed = false;
}